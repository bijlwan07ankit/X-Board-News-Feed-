let accordianDiv = document.querySelector("#accodianDiv");

async function createAccordionItems() {
  const newsData = await getNews();

  for (let i = 0; i < magazines.length; i++) {
    let mainAccHolder = document.createElement("div");
    mainAccHolder.className = "accordion";
    mainAccHolder.setAttribute("id", "accordionPanelsStayOpenExample");

    // Create accordion item
    let accordionItem = document.createElement("div");
    accordionItem.className = "accordion-item my-2";

    let h2 = document.createElement("h2");
    h2.className = "accordion-header";

    let buttonDiv = document.createElement("div");
    buttonDiv.innerHTML = `<button
      class="accordion-button collapsed"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#panelsStayOpen-collapse${i + 1}"
      aria-expanded="false"
      aria-controls="panelsStayOpen-collapse${i + 1}"
    >
      ${newsData[i].feed.title}
    </button>`;

    let mainData = document.createElement("div");
    mainData.setAttribute("id", `panelsStayOpen-collapse${i + 1}`);
    if (i === 0) {
      mainData.className = "accordion-collapse collapse show";
    } else {
      mainData.className = "accordion-collapse collapse";
    }

    let accordionBody = document.createElement("div");
    accordionBody.className = "accordion-body p-0";
    accordionBody.innerHTML = carosalB(newsData, i);

    h2.appendChild(buttonDiv);
    accordionItem.appendChild(h2);
    mainData.appendChild(accordionBody);
    accordionItem.appendChild(mainData);
    mainAccHolder.appendChild(accordionItem);

    accordianDiv.appendChild(mainAccHolder);
  }
}

async function getNews() {
  let dataConverted = [];
  let fetchPromises = magazines.map((magazine) =>
    fetch(`https://api.rss2json.com/v1/api.json?rss_url=${magazine}`)
  );

  let responses = await Promise.all(fetchPromises);
  for (let i = 0; i < magazines.length; i++) {
    let data = await responses[i].json();
    dataConverted.push(data);
  }
  return dataConverted;
}

createAccordionItems();

function carosalB(newsData, iterator) {
  let carouselHTML = `
    <div id="carouselExample${iterator + 1}" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
  `;

  for (let i = 0; i < newsData[iterator].items.length; i++) {
    let item = newsData[iterator].items[i];
    let pubDate = new Date(item.pubDate);
    let formattedPubDate = pubDate.toLocaleDateString('en-In', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });

    carouselHTML += `
      <a target='_blank' href='${item.link}'>
        <div class="carousel-item ${i === 0 ? 'active' : ''}">
          <div class="card">
            <img src="${item.enclosure.link}" class="card-img-top" alt="${item.title}">
            <div class="card-body">
              <h5 class="card-title">${item.title}</h5>
              <h6>${item.author} ⚫ <span>${formattedPubDate}</span> </h6>
              <p class="card-text">${item.description}</p>
            </div>
          </div>
        </div>
      </a>
    `;
  }

  carouselHTML += `
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample${iterator + 1}" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExample${iterator + 1}" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  `;

  return carouselHTML;
}
